package sample;

import javax.swing.plaf.synth.SynthOptionPaneUI;
import java.sql.*;

public class DBUtils {
    static final String DB_PATH = "//localhost:3306/mithology";
    static final String USER = "Java";
    static final String DB_PASS = "javapasswd";
    static Connection connexio;
    public static void Conectar(String DB_PATH, String USER, String DB_PASS) {
        connexio = null;
        try {
            connexio = DriverManager.getConnection(
                    "jdbc:mysql:"+DB_PATH, USER, DB_PASS);
            System.out.println("Connectat amb exit");
        } catch (SQLException e) {
            System.out.println("Error en la connexió " + e);
        }
    }
    //Crea el métode que conectara a la base de dades
    public static void Desconnectar() {
        try{
            if (connexio!=null) {
                connexio.close();
                connexio = null;
            }
            System.out.println("Desconnectat amb exit");
        } catch (SQLException e){
            System.out.println("Error al desconnectar " + e);
        }
    }
    //Crea el métode que desconectara de la base de dades
}
