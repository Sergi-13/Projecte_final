package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import static sample.DBUtils.connexio;

public class Controller {

    @FXML
    private Button select;

    @FXML
    private Button netejar;

    @FXML
    private TextArea sortida;

    @FXML
    void clear(ActionEvent event) {
        sortida.setText("");
    }
    //Borra les dades impreses

    @FXML
    void select(ActionEvent event) {
        String select = "SELECT * FROM `publicacio_personatge`";
        DBUtils.Conectar(DBUtils.DB_PATH, DBUtils.USER, DBUtils.DB_PASS);
        //Crea la query i connecta a la base de dades
        try {
            Statement s = connexio.createStatement();
            ResultSet rs = s.executeQuery (select);
            while (rs.next())//Fa la consulta a la base de dades mentre hi segueixi havent línies a la taula
            {
                String query = sortida.getText();
                sortida.setText(query + rs.getInt (1) + "\t" + rs.getString (2) + "\t"  + rs.getDate (8) + "\t"
                                + rs.getString (9) + "\n");
            }
            //Agafa les dades ja impreses i afegeix les de la següent línia
        } catch (SQLException e){
            System.out.println("Error en l'execució " + e);
            //Imprimeix un error en cas de que la consulta no funcioni
        }
        DBUtils.Desconnectar();
        //Desconnecta de la base de dades
    }
}
