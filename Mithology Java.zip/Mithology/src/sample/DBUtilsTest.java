package sample;

import junit.framework.TestCase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtilsTest extends TestCase {
    static final String DB_PATH = "//localhost:3306/mithology";
    static final String USER = "Java";
    static final String DB_PASS = "javapasswd";
    static Connection connexio;
    public void testConectar() {
        connexio = null;
        try {
            connexio = DriverManager.getConnection(
                    "jdbc:mysql:"+DB_PATH, USER, DB_PASS);
            System.out.println("Connectat amb exit");
        } catch (SQLException e) {
            System.out.println("Error en la connexió " + e);
        }
    }

    public void testDesconnectar() {
        try{
            if (connexio!=null) {
                connexio.close();
                connexio = null;
            }
            System.out.println("Desconnectat amb exit");
        } catch (SQLException e){
            System.out.println("Error al desconnectar " + e);
        }
    }
    //Crea el métode que desconectara de la base de dades
}