-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 30-05-2020 a las 17:59:42
-- Versión del servidor: 10.1.38-MariaDB
-- Versión de PHP: 7.1.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `mithology`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `django_migrations`
--

CREATE TABLE `django_migrations` (
  `id` int(11) NOT NULL,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `publicacio_mitologia`
--

CREATE TABLE `publicacio_mitologia` (
  `id` int(11) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `origen` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `publicacio_mitologia`
--

INSERT INTO `publicacio_mitologia` (`id`, `nom`, `origen`) VALUES
(1, 'Grega', 'Grecia'),
(2, 'Nordica', 'Països germànics');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `publicacio_personatge`
--

CREATE TABLE `publicacio_personatge` (
  `id` int(11) NOT NULL,
  `nom` varchar(40) NOT NULL,
  `especie` varchar(40) NOT NULL,
  `imatge` varchar(100) NOT NULL,
  `poder_arma` varchar(20) NOT NULL,
  `text` varchar(5000) NOT NULL,
  `altres_noms` varchar(100) NOT NULL,
  `data` datetime(6) NOT NULL,
  `id_mitologia_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `publicacio_personatge`
--

INSERT INTO `publicacio_personatge` (`id`, `nom`, `especie`, `imatge`, `poder_arma`, `text`, `altres_noms`, `data`, `id_mitologia_id`) VALUES
(1, 'Zeus', 'Déu', 'NULL', 'el llamp', 'el rei de l\'Olimp', 'Júpiter', '2019-05-27 00:00:00.000000', 1),
(2, 'Poseidó', 'Déu', 'NULL', 'Trident, aigua', 'rei dels mars', 'Neptú', '2019-05-27 00:00:00.000000', 1),
(3, 'Thor', 'Déu', 'NULL', 'Mjolnir', 'Thor es fill d\'Odí', 'NULL', '2019-05-27 00:00:00.000000', 2),
(4, 'Odí', 'Déu', 'NULL', 'Gungnir', 'Odí es el rei d\'Asgard', 'NULL', '2019-05-27 00:00:00.000000', 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `publicacio_preguntes`
--

CREATE TABLE `publicacio_preguntes` (
  `id` int(11) NOT NULL,
  `pregunta` varchar(1500) NOT NULL,
  `resposta` varchar(150) NOT NULL,
  `opcio1` varchar(150) NOT NULL,
  `opcio2` varchar(150) NOT NULL,
  `opcio3` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `publicacio_test`
--

CREATE TABLE `publicacio_test` (
  `id` int(11) NOT NULL,
  `data` datetime(6) NOT NULL,
  `actiu` tinyint(1) NOT NULL,
  `id_personatge_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `django_migrations`
--
ALTER TABLE `django_migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `publicacio_mitologia`
--
ALTER TABLE `publicacio_mitologia`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `publicacio_personatge`
--
ALTER TABLE `publicacio_personatge`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `publicacio_preguntes`
--
ALTER TABLE `publicacio_preguntes`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `publicacio_test`
--
ALTER TABLE `publicacio_test`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `django_migrations`
--
ALTER TABLE `django_migrations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `publicacio_mitologia`
--
ALTER TABLE `publicacio_mitologia`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `publicacio_personatge`
--
ALTER TABLE `publicacio_personatge`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `publicacio_preguntes`
--
ALTER TABLE `publicacio_preguntes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `publicacio_test`
--
ALTER TABLE `publicacio_test`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
