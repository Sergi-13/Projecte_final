from django.shortcuts import render
from django.http import HttpResponseRedirect
from django.contrib.auth import authenticate, login
from django.urls import reverse
from .forms import *

# Create your views here.
def registre(request):
    form = Registrar(request.POST, request.FILES)
   # if request.user.is_authenticated():
    #    return HttpResponseRedirect(reverse('index'))
    context = {'formulari': form}
    if request.method == 'POST':
        context = {'formulari': form, 'POST': True}
        print(form.errors)
        if form.is_valid():
            nick = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            correu = form.cleaned_data.get('correu')
            imatge = form.cleaned_data.get('imatge')
            usr = User(username=nick)
            usr.set_password(password)
            usr.save()
            if form.cleaned_data.get('imatge') is None:
                Usuari.objects.create(user=usr, correu=correu)
            else:
                Usuari.objects.create(user=usr, correu=correu, imatge=imatge)
                usr = authenticate(username=nick, password=password)
                login(request, usr)
            return HttpResponseRedirect(reverse('index'))
    return render(request, 'Registre.html', context)
