function respondre(){
    console.log("respondre");
    var opcio1 = document.getElementById("opcio1");
    var opcio2 = document.getElementById("opcio2");
    var opcio3 = document.getElementById("opcio3");
    var opcio4 = document.getElementById("opcio4");
    var o1 = opcio1.value;
    var o2 = opcio2.value;
    var o3 = opcio3.value;
    var o4 = opcio4.value;
    var correctes = 0;
    var incorrectes = 0;
    var pregunta = document.getElementById("preguntes");
    //console.log("length")
    //console.log(pregunta.length);
    //console.log("Value")
    //console.log(pregunta.value);
    console.log("if")
    for (let i = 0; i < 10 ; i++) {
        if (opcio1.checked) {
            console.log(o1);
            console.log(incorrectes);
        } else if (opcio2.checked) {
            console.log(o2);
            console.log(incorrectes);
        } else if (opcio3.checked) {
            console.log(o3);
            console.log(correctes);
        } else if (opcio4.checked) {
            console.log(o4);
            console.log(incorrectes);
        }
    }
}