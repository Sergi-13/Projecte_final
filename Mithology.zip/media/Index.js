function cercar() {
    criteri = $("#cerca").val(); //Recull el text introduit en el buscador
    if (criteri!="") {
        /*Comprova que realment s'haig introduit un text,
        en cas afirmatiu segueix la funció*/
        $.get("/cerca?criteri="+criteri,function (data) {
           $("#resultats").children().remove();
            /*Fent ús de JQuery crida la URL, que crida la vista que
            utilitzant GET fa la cerca i posteriorment borra les dades
            de la cerca anterior en cas de que n'hi hagi*/
           $.each(data, function (index, element) {
               a = $("<a href=\"/personatge/"+element.id+"\">");
               resultat = $("<div id=\"sortida\">");
               img = $("<img src=\""+element.imatge+"\">");
               p = $("<p>"+element.nom+"</p>");
               resultat.append(img);
               resultat.append(p);
               a.append(resultat);
               $("#resultats").append(a)
           })
            /*A través de JQuery utilitza DOM i afegeix a sota del cercador
             un div i dins del div afegeix un enllaç a la pàgina d'informacio
             del personatge a través de la imatge i del nom d'aquest*/
       })
    }
}


