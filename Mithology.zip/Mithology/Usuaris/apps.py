from django.apps import AppConfig


class UsuarisConfig(AppConfig):
    name = 'Usuaris'
