"""Mithology URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from Publicacions import views
from Usuaris import views as u_views
from django.conf.urls.static import static
from django.conf import settings
from django.urls import include
from django.contrib.auth import views as auth_views
#from django.contrib.auth import login as login

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index, name='index'),
    path('publicacions/', views.publicacions, name='publicacions'),
    path('sortir/', u_views.logout, name='sortir'),
    path('test/', views.test, name='test'),
    path('login/', auth_views.LoginView.as_view(template_name='Inici_sessio.html'), name='login'),
    #path('inici/', u_views.login, {'template_name': 'Inici_sessio.html', 'redirect_authenticated_user': True}, name='inici'),
    #path('accounts/', include('django.contrib.auth.urls')),
    #path('accounts/login/', login, name='login'),
    #path('login/', u_views.inicia, name='inicia'),
    path('registre/', u_views.registre, name='registre'),
    path('personatge/<int:personatge_id>/', views.personatge, name='personatge'),
    path('cerca', views.cerca, name='cerca'),
    path('publicar/', views.publicar, name='publicar'),
    path('solucions', views.solucions, name='soluncions')
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
