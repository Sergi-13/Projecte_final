from django import forms
from Publicacio.models import *


class TestForm (forms.ModelForm):
    class Meta:
        model = Test
        fields = "__all__"


class PublicacioForm (forms.ModelForm):
    class Meta:
        model = Personatge
        fields = "__all__"


class PreuntaForm (forms.ModelForm):
    class Meta:
        model = Preguntes
        fields = "__all__"


class MitologiaForm (forms.ModelForm):
    class Meta:
        model = Mitologia
        fields = "__all__"
