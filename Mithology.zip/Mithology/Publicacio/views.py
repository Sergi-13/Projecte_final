from django.shortcuts import render
from django.urls import reverse
from django.http import HttpResponseRedirect
from django.contrib.auth.models import User
from Usuaris.models import Usuari
from Publicacio.models import Personatge
from Publicacio.models import Test
from Publicacio.forms import TestForm


# Create your views here.
def index(request):
    personatges = Personatge.objects.order_by('nom')[0]
    a = request.user.is_authenticated
    print(a)
    # if request.user.is_authenticated():
    #     context = {'personatges': personatges, 'username': request.user.username}
    # else:
    context = {'personatges': personatges}
    return render(request, 'Inici.html', context)
