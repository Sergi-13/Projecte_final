from django.apps import AppConfig


class PublicacioConfig(AppConfig):
    name = 'Publicacio'
