function cercar() {
    criteri = $("#criteri").val();
    if (criteri != "") {
        console.log(criteri);
        $.get("/cerca?buscar=" + criteri, function (data) {
           console.log(data);
           $("#resultats").children().remove();
           $.each(data, function (index, element) {
               console.log(index);
               console.log(element);
               a = $("<a href=\"/curiositat/"+element.id+"\">")
               resultat = $("<div id=\"resultats\">")
               img = $("<img src=\""+element.imatge+"\">")
               p = $("<p>"+elememt.nom+"</p>");
               resultat.append(img)
               resultat.append(p)
               a.append(resultat)
               $("#resultats").append(a)
           })
       })
    }
}