//respondre();
function respondre(){
    var opcio1= document.getElementById("opcio1")
    console.log("opcio1     "+opcio1.value);
    var opcio2= document.getElementById("opcio2");
    console.log("opcio2     "+opcio2.value);
    var opcio3= document.getElementById("opcio3");
    console.log("opcio3     "+opcio3.value);
    var opcio4= document.getElementById("opcio4");
    console.log("opcio4     "+opcio4.value);
    var o1 = document.getElementById("o1");
    var o2 = document.getElementById("o2");
    var o3 = document.getElementById("o3");
    var o4 = document.getElementById("o4");
    var aleatori = Math.floor(Math.Random()*4)+1;
    switch (aleatori) {
        case 1:
            opcio1.value = "{{ pregunta.opcio1 }}";
            var t1 = document.createTextNode("{{ pregunta.opcio1 }}")
            o1.appendChild(t1)
            opcio2.value = "{{ pregunta.opcio2 }}";
            var t2 = document.createTextNode("{{ pregunta.opcio2 }}")
            o2.appendChild(t2)
            opcio3.value = "{{ pregunta.opcio3 }}";
            var t3 = document.createTextNode("{{ pregunta.opcio3 }}")
            o3.appendChild(t3)
            opcio4.value = "{{ pregunta.resposta }}";
            var t4 = document.createTextNode("{{ pregunta.resposta }}")
            o4.appendChild(t4)
            break;
        case 2:
            opcio1.value = "{{ pregunta.opcio2 }}";
            var t1 = document.createTextNode("{{ pregunta.opcio2 }}")
            o1.appendChild(t1)
            opcio2.value = "{{ pregunta.opcio3 }}";
            var t2 = document.createTextNode("{{ pregunta.opcio3 }}")
            o2.appendChild(t2)
            opcio3.value = "{{ pregunta.resposta }}";
            var t3 = document.createTextNode("{{ pregunta.resposta }}")
            o3.appendChild(t3)
            opcio4.value = "{{ pregunta.opcio1 }}";
            var t4 = document.createTextNode("{{ pregunta..opcio1 }}")
            o4.appendChild(t4)
            break;
        case 3:
            opcio1.value = "{{ pregunta.opcio3 }}";
            var t1 = document.createTextNode("{{ pregunta.opcio3 }}")
            o1.appendChild(t1)
            opcio2.value = "{{ pregunta.resposta }}";
            var t2 = document.createTextNode("{{ pregunta.resposta }}")
            o2.appendChild(t2)
            opcio3.value = "{{ pregunta.opcio1 }}";
            var t3 = document.createTextNode("{{ pregunta.opcio1 }}")
            o3.appendChild(t3)
            opcio4.value = "{{ pregunta.opcio2 }}";
            var t4 = document.createTextNode("{{ pregunta..opcio2 }}")
            o4.appendChild(t4)
            break;
        case 4:
            opcio1.value = "{{ pregunta.resposta }}";
            var t1 = document.createTextNode("{{ pregunta.resposta }}")
            o1.appendChild(t1)
            opcio2.value = "{{ pregunta.opcio1 }}";
            var t2 = document.createTextNode("{{ pregunta.opcio1 }}")
            o2.appendChild(t2)
            opcio3.value = "{{ pregunta.opcio2 }}";
            var t3 = document.createTextNode("{{ pregunta.opcio2 }}")
            o3.appendChild(t3)
            opcio4.value = "{{ pregunta.opcio3 }}";
            var t4 = document.createTextNode("{{ pregunta.opcio3 }}")
            o4.appendChild(t4)
            break;
    }
}
