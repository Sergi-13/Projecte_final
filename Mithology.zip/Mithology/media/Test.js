function respondre(){
    var opcio1= document.getElementById("opcio1").value;
    var opcio2= document.getElementById("opcio2").value;
    var opcio3= document.getElementById("opcio3").value;
    var opcio4= document.getElementById("opcio4").value;
    if (opcio1.checked) {
        console.log(opcio1);
    } else if (opcio2.checked) {
        console.log(opcio2);
    } else if (opcio3.checked) {
        console.log(opcio3);
    } else if (opcio4.checked) {
        console.log(opcio4);
    }
}
