from django.shortcuts import render

# Create your views here.
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, get_object_or_404
from django.shortcuts import render
from django.urls import reverse
from django.http import HttpResponseRedirect, HttpResponse
from django.contrib.auth.models import User
from Usuaris.models import Usuari
from Publicacions.models import Personatge
from Publicacions.models import Mitologia
from Publicacions.models import Preguntes
from Publicacions.models import Test
from Publicacions.forms import *

import json


# Create your views here.
def index(request):
    personatges = Personatge.objects.order_by('data')[0]
    # if request.user.is_authenticated():
    #     context = {'personatges': personatges, 'username': request.user.username}
    # else:-
    context = {'personatges': personatges}
    return render(request, 'Index.html', context)


def publicacions(request):
    personatges = Personatge.objects.order_by('-data')
    context = {'personatges': personatges}
    return render(request, 'Publicacions.html', context)


@login_required()
def test(request):
    personatge = Personatge.objects.order_by('data')[0]
    nom = personatge.nom
    id = personatge.pk
    print(nom)
    print(id)
    preguntes = Preguntes.objects.filter(id_test=id)
    context = {'preguntes': preguntes}
    return render(request, 'Test.html', context)


def personatge(request, personatge_id):
    personatge = Personatge.objects.get(pk=personatge_id)
    context = {'personatge': personatge}
    return render(request, 'Personatge.html', context)


@login_required()
def solucions(request):
    personatge = Personatge.objects.order_by('data')[0]
    preguntes = Preguntes.objects.filter(id_test=personatge.pk)
    context = {'preguntes': preguntes}
    return render(request, "Solucions.html", context)


def cerca(request):
    if request.method == "GET":
        text = request.GET.get('criteri')
        llista = Personatge.objects.filter(nom__icontains=text)
        print(llista)
        sortida = [estructura(cerca) for cerca in llista]
        return HttpResponse(json.dumps(sortida), content_type='aplication/json')
    HttpResponseRedirect(reverse('index'))


def estructura(llista):
    print (llista)
    return {'id': llista.id, 'nom': llista.nom, 'imatge': llista.imatge.url}


def publicar(request, personatge_id=None):
    if personatge_id:
        publi = Personatge.objects.get(pk=personatge_id)
        print("Editar")
    else:
        publi = Personatge()
        print("No es pot editar")
    if request.method=='POST':
        form = PersonatgeForm(request.POST, instance=publi)
        if form.is_valid():
            form.save()
            print("Tot ha anat bé has editat o afegit")
            return HttpResponseRedirect(reverse("publicacions"))
        else:
            print("Tot ha fallat no has afegit o no has pogut editar")
    else:
        form = PersonatgeForm(instance=publi)
        print("else 2")
    return render(request, 'CrearPublicacio.html', {'form':form})


# def publicar(request):
#     form = PersonatgeForm(request.POST, request.FILES)
#     if request.method == 'POST':
#         if form.is_valid():
#             nom = form.cleaned_data.get('nom')
#             especie = form.cleaned_data.get('especie')
#             imatge = form.cleaned_data.get('imatge')
#             poder_arma = form.cleaned_data.get('poder_arma')
#             text = form.cleaned_data.get('text')
#             altres_noms = form.cleaned_data.get('altres_noms')
#             personatge = Personatge(nom=nom, especie=especie, imatge=imatge, poder_arma=poder_arma, text=text, altres_noms=altres_noms)
#             personatge.save()
#             return HttpResponseRedirect(reverse('Index'))
#     context = {'formulari': form}
#     return render(request, 'CrearPublicacio.html', context)
    # form = PublicacioForm(request.POST, request.FILES)
    # if request.method == 'POST':
    #     if form.is_valid():
    #         # form.save(commit=False)
    #    #     usuari = User.objects.get(username=request.user.username)
    #     #    usuari2 = Usuaris.objects.get(usuari=usuari)
    #         nom = form.cleaned_data.get('nom')
    #         especie = form.cleaned_data.get('especie')
    #         poder_arma = form.cleaned_data.get('poder_arma')
    #         text = form.cleaned_data.get('text')
    #         altres_noms = form.cleaned_data.get('altres_noms')
    #         data = form.cleaned_data.get('data')
    #         personatge = Mitologia(nom=nom, especie=especie, poder_arma=poder_arma, text=text, altres_noms=altres_noms, data=data)
    #         personatge.save()
    #         return HttpResponseRedirect(reverse('Index'))
    # formCategoria = PublicacioForm(request.POST)
    # context = {'formulari': form}
    # return render(request, 'CrearPublicacio.html', context)