from django import forms
from Publicacions.models import *


class TestForm (forms.ModelForm):
    class Meta:
        models = Test
        fields = "__all__"


class PersonatgeForm (forms.ModelForm):
    class Meta:
       model = Personatge
       fields = "__all__"
# class PersonatgeForm(forms.Form):
#     nom = forms.CharField(required=True)
#     especie = forms.CharField(required=True)
#     imatge = forms.ImageField()
#     poder_arma = forms.CharField()
#     text = forms.CharField(widget=forms.Textarea)
#     altres_noms = forms.CharField()


class MitologiaForm (forms.ModelForm):
    class Meta:
        models = Mitologia
        fields = "__all__"
