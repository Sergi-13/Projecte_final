from django import forms
from Publicacions.models import *


class TestForm (forms.ModelForm):
    class Meta:
        models = Test
        fields = "__all__"


class PersonatgeForm (forms.ModelForm):
    class Meta:
       model = Personatge
       fields = "__all__"


class MitologiaForm (forms.ModelForm):
    class Meta:
        models = Mitologia
        fields = "__all__"
