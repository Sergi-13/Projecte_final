from django import forms
from Publicacions.models import *


class TestForm (forms.ModelForm):
    class Meta:
        models = Test
        fields = "__all__"


class PublicacioForm (forms.ModelForm):
    class Meta:
        models = Personatge
        fields = "__all__"


class MitologiaForm (forms.ModelForm):
    class Meta:
        models = Mitologia
        fields = "__all__"
