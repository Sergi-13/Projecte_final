from django.apps import AppConfig


class PublicacionsConfig(AppConfig):
    name = 'Publicacions'
