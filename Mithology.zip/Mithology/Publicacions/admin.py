from django.contrib import admin
from .models import *

# Register your models here.
admin.site.register(Mitologia)
admin.site.register(Personatge)
admin.site.register(Test)
admin.site.register(Preguntes)
