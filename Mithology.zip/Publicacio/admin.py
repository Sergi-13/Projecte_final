from django.contrib import admin

# Register your models here.
from .models import *

admin.site.register(Mitologia)
admin.site.register(Personatge)
admin.site.register(Test)