from django.shortcuts import render
from Publicacio.models import Test
from Usuaris.models import Usuari


# Create your views here.
def crearTest(request):
    preguntes = Test.objects.filter(actiu=True)
    resposta = Test.objects.filter(pk=preguntes.pk)
    opcions = Test.objects.filter(pk=preguntes.pk)
    context = {'pregunta': preguntes, 'resposta': resposta, 'opcions': opcions}
    #context = {'pregunta': preguntes}
    if request.user.is_authenticated():
        usuari = Usuari.objects.get(usuari=request.user)
    return render(request, 'CrearTest.html')
