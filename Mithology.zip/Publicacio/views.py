from django.shortcuts import render
from django.urls import reverse
from django.http import HttpResponseRedirect
from .models import Personatge
from .models import Test
from .forms import TestForm


# Create your views here.
def index(request):
    personatges = Personatge.objects.order_by('nom')[0]
    context = {'personatges': personatges}
    return render(request, 'Inici.html', context)
